import { Component, OnInit } from '@angular/core';
import { RecipeService } from '../recipe.service';
import { UserService } from '../user.service';
import { Recipe } from '../recipe.model';  // Import the Recipe model
import { user } from '../user';

@Component({
  selector: 'app-endorse-recipe',
  templateUrl: './endorserecipe.component.html',
  styleUrls: ['./endorserecipe.component.css']
})
export class EndorseRecipeComponent implements OnInit {
  recipes: Recipe[] = [];
  user: user | null = null;

  constructor(private recipeService: RecipeService, private userService: UserService) {}

  ngOnInit(): void {
    this.loadHealthyRecipes();
    this.loadUser();
  }

  loadHealthyRecipes(): void {
    this.recipeService.getHealthyRecipes().subscribe(
      (data: Recipe[]) => {
        this.recipes = data;
      },
      error => {
        console.error('Error fetching recipes', error);
      }
    );
  }

  loadUser(): void {
    this.user = this.userService.getUserFromStorage();
  }

  endorse(recipeId: number): void {
    if (!this.user) {
      console.error('User not logged in');
      return;
    }

    this.recipeService.endorseRecipe(recipeId, this.user.id).subscribe(
      response => {
        console.log('Recipe endorsed successfully', response);
        this.loadHealthyRecipes();
      },
      error => {
        console.error('Error endorsing recipe', error);
      }
    );
  }
}
