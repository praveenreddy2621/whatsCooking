import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
 
export function passwordValidator() {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const value = control.value || '';
    const hasUpperCase = /[A-Z]/.test(value);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(value);
    const valid = hasUpperCase && hasSpecialChar;
 
    return !valid ? { passwordStrength: true } : null;
  };
}
 
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string | null = null;
 
  constructor(private http: HttpClient, private router: Router, private fb: FormBuilder) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8), passwordValidator()]],
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      role: ['USER']  // Default role
    });
  }
 
  onSubmit() {
    if (this.registerForm.valid) {
      this.http.post('http://localhost:8087/users/register', this.registerForm.value)
        .subscribe({
          next: (response: any) => {
            console.log('Registration successful:', response);
            alert('Registration successful');
            this.router.navigate(['/login']);
          },
          error: (error: any) => {
            console.error('Registration failed:', error);
            this.errorMessage = 'Registration failed: ' + (error.message || 'Unknown error');
          }
        });
    }
  }
}
 