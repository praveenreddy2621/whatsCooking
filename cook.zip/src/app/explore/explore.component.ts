import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-explore',
  templateUrl: './explore.component.html',
  styleUrls: ['./explore.component.css']
})
export class ExploreComponent implements OnInit {
  title = 'WhatsCooking';
  dishes: any[] = [
    { id: 10, name: "Gobi Manchuian", photo: "https://tse1.mm.bing.net/th/id/OIP.0nwXrzbA_8RbzOp0EXEF7gHaE6?w=298&h=198&c=7&r=0&o=5&pid=1.7" },
    { id: 13, name: "Paneer Tikka", photo: "https://tse1.mm.bing.net/th/id/OIP.QnjA_HStthtdvYCFg80znAHaFM?w=272&h=191&c=7&r=0&o=5&pid=1.7" },
    { id: 48, name: "Chicken Biryani", photo: "https://sapanarestaurant.com/wp-content/uploads/2019/11/authentic-chicken-biryani.jpg" },
    { id: 15, name: "Aloo Tikka", photo: "https://tse4.mm.bing.net/th/id/OIP.ASs_LJ_XhL7Sp4R4oW6q8gHaHa?w=192&h=192&c=7&r=0&o=5&pid=1.7" },
    { id: 16, name: "Margarita Pizza", photo: "https://realfood.tesco.com/media/images/1400x919-MargaritaPizza-555a4065-2573-4b41-bcf3-7193cd095d8f-0-1400x919.jpg" },
    { id: 17, name: "Spaghetti Carbonara", photo: "https://bing.com/th?id=OSK.04cc3677a177c1bd0077793ffa1f1c56" },
    { id: 18, name: "Chicken Curry", photo: "https://www.funfoodfrolic.com/wp-content/uploads/2020/09/Chicken-Curry-Thumbnail.jpg" },
    { id: 19, name: "Vegetable Stir Fry", photo: "https://bing.com/th?id=OSK.10960a6ade645a432dd7a61d3f323bec" },
    { id: 20, name: "Chicken Tacos", photo: "https://bing.com/th?id=OSK.8108741c0db756b236596ad8090792a6" },
    { id: 21, name: "Palak Paneer", photo: "https://www.recipestrainrestaurant.com/photos/VZDJy4MOXhghoVyyQYIGpd22ODayOevi.jpg" },
    { id: 23, name: "Aloo Gobi", photo: "https://tse1.mm.bing.net/th/id/OIP.fBre3e2d4PTiSvEs04fCDAHaE8?rs=1&pid=ImgDetMain" },
    { id: 24, name: "Butter Chicken", photo: "https://media-cdn.tripadvisor.com/media/photo-s/23/f1/d7/38/butter-chicken.jpg" },
    { id: 25, name: "Rajma", photo: "https://foodtasted.org/wp-content/uploads/2019/03/Rajma_Masala.jpg" },
    { id: 26, name: "Dosa", photo: "https://vismaifood.com/storage/app/uploads/public/8b4/19e/427/thumb__1200_0_0_0_auto.jpg" },
    { id: 27, name: "Idly", photo: "https://boldoutline.in/wp-content/uploads/2020/01/web-cover-57.jpg" },
    { id: 28, name: "Samosa", photo: "https://tse2.mm.bing.net/th/id/OIP.qHJIzQ-WXnx8QZBmQRaPHQHaE3?rs=1&pid=ImgDetMain" },
    { id: 29, name: "Aaloo paratha", photo: "https://cdn.cdnparenting.com/articles/2020/01/19152919/Aloo-Paratha-Recipe.jpg" },
    { id: 30, name: "Dal Makhani", photo: "https://im.whatshot.in/img/2019/Dec/shutterstock-774185014-cropped-1577167739.jpg" },
    { id: 31, name: "Pav Bhaji", photo: "https://www.elgiultra.com/ultraliving/wp-content/uploads/2019/10/pav-bhaji.jpg" },
    { id: 32, name: "Mutton Gravy", photo: "https://i.ytimg.com/vi/mJ8kw-5ifzE/maxresdefault.jpg" },
    { id: 33, name: "Curd Rice", photo: "https://images.indianexpress.com/2023/10/curd-rice_1200_getty.jpg" },
    { id: 34, name: "Bhindi Masala", photo: "https://i.ytimg.com/vi/4yQ8uq1YAyo/maxresdefault.jpg" },
    { id: 35, name: "Baingan Bharta", photo: "https://i.pinimg.com/736x/08/7e/6e/087e6ed3578284f4eb3a2d886c7bc5bd.jpg" },
    { id: 36, name: "Kofta Curry", photo: "https://i.ytimg.com/vi/wFF0CuYTKDk/maxresdefault.jpg" },
    { id: 37, name: "Kachori", photo: "https://www.archanaskitchen.com/images/archanaskitchen/1-Author/Madhuri_Aggarwal/Matar_Kachori_Recipe-6.jpg" },
    { id: 38, name: "pulao", photo: "https://i.ytimg.com/vi/wFF0CuYTKDk/maxresdefault.jpg" },
    { id: 39, name: "Pesarattu", photo: "https://tse2.mm.bing.net/th/id/OIP.mpNpg66Y4b0VoMSQhbSwjQHaEK?rs=1&pid=ImgDetMain" },
    { id: 40, name: "Kichidi", photo: "https://tse4.mm.bing.net/th/id/OIP.A09Ij3m0WQzZvsUMxLz8QQHaEK?rs=1&pid=ImgDetMain" },
    { id: 41, name: "Dhokla", photo: "https://tse1.mm.bing.net/th/id/OIP.bk7ghQRb1LmC0Fek0VswUQHaEP?w=750&h=430&rs=1&pid=ImgDetMain" },
    { id: 42, name: "Rava Kesari", photo: "https://www.vegrecipesofindia.com/wp-content/uploads/2019/01/rava-kesari-recipe-1a.jpg" },
    { id: 43, name: "Rasam", photo: "https://vismaifood.com/storage/app/uploads/public/2f7/20d/779/thumb__1200_0_0_0_auto.jpg" },
    { id: 44, name: "Gajar Ka Halwa", photo: "https://foodhistoria.com/wp-content/uploads/2023/03/Original_18109_gajar-halwa.jpg" },
    { id: 45, name: "Chana Masala", photo: "https://i.ytimg.com/vi/eg0ZrgLXMV8/maxresdefault.jpg" },
    { id: 46, name: "Kheer", photo: "https://tse1.mm.bing.net/th/id/OIP.QDoECtwLJn0nStt6MtfNCQHaEK?rs=1&pid=ImgDetMain" },
    { id: 47, name: "Tandoori Chicken", photo: "https://tse1.mm.bing.net/th/id/OIP.21xfGQ9jUczQhBfBTgASHwHaEJ?rs=1&pid=ImgDetMain" },
    { id: 48, name: "Chole Bhature", photo: "https://assets.gqindia.com/photos/5e13119f28dff200080a598d/master/pass/top-image.jpg" },
   
    

  ];
  filteredDishes: any[] = [];
  searchQuery: string = '';
  paginatedDishes: any[] = [];
  currentPage: number = 1;
  itemsPerPage: number = 12;
  totalPages: number = 0;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.filteredDishes = this.dishes;
    this.updatePaginatedDishes();
  }

  onSearch(): void {
    this.filteredDishes = this.dishes.filter(dish =>
      dish.name.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
    this.currentPage = 1;
    this.updatePaginatedDishes();
  }

  onPageChange(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedDishes();
    }
  }

  updatePaginatedDishes(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedDishes = this.filteredDishes.slice(startIndex, endIndex);
    this.totalPages = Math.ceil(this.filteredDishes.length / this.itemsPerPage);
  }

  viewRecipe(id: number): void {
    this.router.navigate(['/recipe', id]);
  }

  resetSearch() {
    this.searchQuery = '';
    this.filteredDishes = [...this.dishes];
    this.currentPage = 1;                  
    this.updatePaginatedDishes();        
  }

  sortSearch() {
    this.searchQuery = '';
    this.dishes.sort((a, b) => a.name.localeCompare(b.name));
    this.filteredDishes = [...this.dishes];
    this.currentPage = 1;
    this.updatePaginatedDishes();
  }
  sortSearchdes() {
    // Reset the search query
    this.searchQuery = '';

    // Sort the dishes in descending alphabetical order by name
    this.dishes.sort((a, b) => b.name.localeCompare(a.name));

    // Update the filtered dishes to the sorted list
    this.filteredDishes = [...this.dishes];

    // Reset to the first page
    this.currentPage = 1;

    // Update the paginated dishes display
    this.updatePaginatedDishes();
}
}
