// recipe.model.ts
export interface Recipe {
    id?: number;
    description: string;
    enabled:boolean;
    endorsed:boolean;
    ingredients:string;
    name:string;
    steps:string;
    img : string;
    likesCount?: number;
  }
  