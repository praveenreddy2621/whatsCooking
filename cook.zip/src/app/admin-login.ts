export class user{
    id!: number;
    password!: string;
    email!: string;
    role!: string;
}
