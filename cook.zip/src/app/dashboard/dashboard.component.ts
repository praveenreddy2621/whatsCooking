import { Component ,OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { user } from '../user.service';
 
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user: user | null = null;
  router: any;

  constructor(private userService: UserService) {}
 
    ngOnInit(): void {
    this.user = this.userService.getUserFromStorage();}

  
  // logout() {
  //   // Clear user session or token here
  //   localStorage.removeItem('userToken'); // Adjust based on your session management

  //   // Navigate to the login page
  //   this.router.navigate(['/login']).then(() => {
  //     // Clear history to prevent going back
  //     window.history.forward();
  //   });
  // }
  logout() {
    // Clear user session or token here
    // e.g., localStorage.removeItem('userToken');
    // Navigate to the login page or home page
    this.router.navigate(['/login']); // Change '/login' to your login route
  }
}
 
 
 