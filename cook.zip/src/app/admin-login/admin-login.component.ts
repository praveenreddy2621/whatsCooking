import { Component, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.component';
import { AdminService } from '../admin-login.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {
  loginForm: FormGroup;
  loginError: string | null = null;
  adminService: any;

  constructor(
    private fb: FormBuilder,
    private authService: AdminService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.loginForm = this.fb.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { emailId, password } = this.loginForm.value;
      this.authService.login(emailId, password).subscribe(
        (response: any) => {
          console.log('Login successful', response);
          alert('Login successful');

          localStorage.setItem('admin', JSON.stringify(response));
          this.router.navigate(['/admin-portal']);
        },
        (error: any) => {
          this.loginError = 'Invalid email or password';
          this.cdr.detectChanges();  // Force Angular to update the view
          console.error('Login error', error);
        }
      );
    } else {
      this.loginError = 'Please enter valid email and password.';
    }
  }
}
