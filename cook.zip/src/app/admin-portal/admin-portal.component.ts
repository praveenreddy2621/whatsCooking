import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RecipeService } from '../recipe.service';  // Adjust the path as necessary
import { Recipe } from '../recipe.model';  // Adjust the path as necessary

@Component({
  selector: 'app-admin-portal',
  templateUrl: './admin-portal.component.html',
  styleUrls: ['./admin-portal.component.css']
})
export class AdminPortalComponent implements OnInit {
  recipeForm: FormGroup;
  recipes: Recipe[] = [];
  currentRecipeId: number | null = null;
  isEditMode: boolean = false;
  successMessage: string | null = null; // Add this property
  userService: any;

  constructor(private fb: FormBuilder, private recipeService: RecipeService) {
    this.recipeForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      ingredients: ['', Validators.required],
      steps: ['', Validators.required],
      enabled: [false],
      endorsed: [false],
      img:['']
      
    });
  }


  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.recipeForm.patchValue({
          img: reader.result as string // Convert to base64
        });
      };
      reader.readAsDataURL(file); // Convert file to base64
    }
  }

  ngOnInit(): void {
    this.loadRecipes();
  }

  loadRecipes(): void {
    this.recipeService.getAllRecipes().subscribe(
      (data: Recipe[]) => {
        this.recipes = data;
      },
      error => {
        console.error('Error fetching recipes', error);
      }
    );
  }

  onSubmit(): void {
    if (this.recipeForm.valid) {
      const recipe: Recipe = this.recipeForm.value;
      console.log('Submitting recipe:', recipe); // Debug logging

      if (this.isEditMode && this.currentRecipeId) {
        this.recipeService.updateRecipe(this.currentRecipeId, recipe).subscribe(
          (updatedRecipe) => {
            console.log('Updated recipe:', updatedRecipe); // Debug logging
            this.successMessage = 'Recipe updated successfully!';
            this.loadRecipes();
            this.resetForm();
          },
          error => {
            console.error('Error updating recipe', error);
          }
        );
      } else {
        this.recipeService.createRecipe(recipe).subscribe(
          (newRecipe) => {
            console.log('New recipe:', newRecipe); // Debug logging
            this.successMessage = 'Recipe added successfully!';
            alert('Recipe Added successfully');
            this.loadRecipes();
            this.resetForm();
          },
          error => {
            console.error('Error adding recipe', error);
          }
        );
      }
    }
  }

  editRecipe(recipe: Recipe): void {
    this.currentRecipeId = recipe.id;
    this.isEditMode = true;
    this.recipeForm.patchValue({
      name: recipe.name,
      description: recipe.description,
      ingredients: recipe.ingredients,
      steps: recipe.steps,
      enabled: recipe.enabled,
      endorsed: recipe.endorsed,
      img : recipe.img
    });
  }

  deleteRecipe(id: number): void {
    this.recipeService.deleteRecipe(id).subscribe(
      () => {
        this.successMessage = 'Recipe deleted successfully!';
        this.loadRecipes();
      },
      error => {
        console.error('Error deleting recipe', error);
      }
    );
  }
  

  resetForm(): void {
    this.recipeForm.reset();
    this.isEditMode = false;
    this.currentRecipeId = null;
    setTimeout(() => this.successMessage = null, 5000); // Clear message after 5 seconds
  }
  //

  likeRecipe(recipeId: number): void {
    const username = this.userService.getUsername(); // Fetch the username of the currently logged-in user
    this.recipeService.likeRecipe(recipeId, username).subscribe(
      () => {
        console.log('Recipe liked successfully');
        this.loadRecipes(); // Refresh the recipe list to update likes count
      },
      error => {
        console.error('Error liking recipe', error);
      }
    );
  }
  //
}
