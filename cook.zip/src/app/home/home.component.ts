import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';  // Ensure this service is available

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  constructor(private router: Router, private userService: UserService) { }

  // Method to perform some action when the button is clicked
  performAction(): void {
    // Example action: Navigate to another route
    this.router.navigate(['/dashboard']);
  }
}
