export interface Comment {
    id?: number;
    recipe_id?: number;
    content: string;
  }
  