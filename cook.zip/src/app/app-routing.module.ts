import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { EndorseRecipeComponent } from './endorserecipe/endorserecipe.component';
import { ExploreComponent } from './explore/explore.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminPortalComponent } from './admin-portal/admin-portal.component';
import { RecipeDetailComponent } from './recipedetail/recipedetail.component';
import { CommentComponent } from './comment/comment.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
   { path: 'dashboard', component: DashboardComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'explore', component: ExploreComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'endorserecipe', component: EndorseRecipeComponent },
  { path: 'admin-login',component:AdminLoginComponent},
  { path: 'admin-portal', component:AdminPortalComponent},
  { path: 'explore', component: ExploreComponent },
  { path: 'recipe/:id', component: RecipeDetailComponent },
  { path: '', redirectTo: '/explore', pathMatch: 'full' },
  { path: 'comment', component: CommentComponent },
  { path: 'user', component: UserComponent },
  









];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
