import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { user } from '../user';
 
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user: user | null = null;
  newPassword: string = '';
  userId: number = 1; // Set this to the ID of the user you want to fetch
 
  constructor(private userService: UserService) {}
 
  ngOnInit(): void {
    this.loadUserDetails();
  }
 
  loadUserDetails(): void {
    const storedUser = this.userService.getUserFromStorage();
    if (storedUser) {
      this.userId = storedUser.id;
      this.userService.getUser(this.userId).subscribe(
        user => this.user = user,
        error => console.error('Error fetching user details', error)
      );
    }
  }
 
  updatePassword(): void {
    if (this.newPassword.trim()) {
      this.userService.changePassword(this.userId, this.newPassword).subscribe(
        updatedUser => {
          this.user = updatedUser;
          this.newPassword = ''; // Clear the input field
          alert('Password updated successfully!');
        },
        error => console.error('Error updating password', error)
      );
    } else {
      alert('Please enter a new password');
    }
  }
}
 