import { Component, Input, OnInit } from '@angular/core';
import { CommentService } from '../comment.service'; // Ensure the path is correct
import { Comment } from '../comment';// Ensure the correct path to the model

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
  @Input() recipeId!: number; // Recipe ID to which the comments are associated
  @Input() userId!: number; // User ID of the person commenting
  newComment: string = '';
  comments: Comment[] = [];

  constructor(private commentService: CommentService) {}

  ngOnInit(): void {
    this.loadComments();
  }

  loadComments(): void {
    this.commentService.getCommentsByRecipeId(this.recipeId).subscribe(data => {
      this.comments = data;
    });
  }

  addComment(): void {
    if (this.newComment.trim()) {
      const comment: Comment = {
        recipe_id: this.recipeId, // Use recipe_id to match the interface
        content: this.newComment
      };

      this.commentService.addComment(comment).subscribe(data => {
        this.comments.push(data); // Add the new comment to the list
        this.newComment = ''; // Clear input after adding comment
      });
    }
  }
}
