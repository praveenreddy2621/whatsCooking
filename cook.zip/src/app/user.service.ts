import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { user } from './user';  // Make sure this path is correct

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getUsername() {
    throw new Error('Method not implemented.');
  }
  private baseURL = `http://localhost:8087/users`;

  constructor(private http: HttpClient) {}

  // Register a new user
  registerUser(user: user): Observable<user> {
    return this.http.post<user>(`${this.baseURL}/register`, user)
      .pipe(catchError(this.handleError));
  }

  // Login user and get a token
  loginUser(credentials: { username: string, password: string }): Observable<any> {
    return this.http.post<any>(`${this.baseURL}/login`, credentials)
      .pipe(catchError(this.handleError));
  }

  // Get user by ID
  getUser(id: number): Observable<user> {
    return this.http.get<user>(`${this.baseURL}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Get all users
  getAllUsers(): Observable<user[]> {
    return this.http.get<user[]>(this.baseURL)
      .pipe(catchError(this.handleError));
  }

  // Update user details
  updateUser(id: number, userDetails: user): Observable<user> {
    return this.http.put<user>(`${this.baseURL}/${id}`, userDetails)
      .pipe(catchError(this.handleError));
  }

  // Delete user by ID
  deleteUser(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseURL}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Change user password
  changePassword(id: number, newPassword: string): Observable<user> {
    return this.http.put<user>(`${this.baseURL}/${id}/password`, newPassword, {
      headers: new HttpHeaders({ 'Content-Type': 'text/plain' })
    }).pipe(catchError(this.handleError));
  }

  // Error handling
  private handleError(error: any): Observable<never> {
    console.error('An error occurred', error);
    return throwError(error);
  }

  // Implement logout logic
  logoutUser(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user'); // Clear user data on logout
  }

  // Retrieve user from local storage
  getUserFromStorage(): user | null {
    try {
      const userData = localStorage.getItem('user');
      if (userData) {
        return JSON.parse(userData) as user;
      }
    } catch (error) {
      console.error('Error parsing user data from local storage', error);
    }
    return null;
  }
  // getCurrentUser(): Observable<any> {
  //   // Replace with actual implementation to get the current user
  //   return this.http.get<any>(`${this.baseURL}/current`); // Example endpoint
  // }
  getCurrentUsername(): Observable<string> {
    return this.http.get<string>('http://localhost:8087/current-username'); // Adjust endpoint as needed
  }

  //
 
  //
}
export { user };

