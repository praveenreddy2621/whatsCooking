import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RecipeService } from '../recipe.service';
import { UserService } from '../user.service';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipedetail',
  templateUrl: './recipedetail.component.html',
  styleUrls: ['./recipedetail.component.css']
})
export class RecipeDetailComponent implements OnInit {
  recipe: any;
  newComment: string = ''; 
  // Ensure to initialize this as an empty string
  username :string="";
  likeCount: any;

  constructor(
    private route: ActivatedRoute,
    private recipeService: RecipeService,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    if (id) {
      this.loadRecipe(id);
    } else {
      console.error('Recipe ID is missing');
    }
  }

  loadRecipe(id: number): void {
    this.recipeService.getRecipeById(id).subscribe(
      data => {
        this.recipe = data;
        this.loadLikesCount(id); // Load likes count once recipe is fetched
      },
      error => {
        console.error('Error fetching recipe:', error);
      }
    );
  }

  loadLikesCount(id: number): void {
    this.recipeService.getLikesCount(id).subscribe(
      count => {
        if (this.recipe) {
          this.recipe.likesCount = count; // Ensure recipe is defined
        }
      },
      error => {
        console.error('Error fetching likes count:', error);
      }
    );
  }

  addComment(): void {
    if (this.recipe && this.newComment.trim()) {
      this.recipeService.addComment(this.recipe.id, this.newComment).subscribe(
        () => {
          this.newComment = ''; // Clear input after adding comment
          this.router.navigate(['/explore']); // Redirect to explore page or refresh
        },
        error => {
          console.error('Error adding comment:', error);
        }
      );
    }
  }

  goBack(): void {
    this.router.navigate(['/explore']); // Use router to navigate
  }

  // likeRecipe(): void {
  //   const username = '{{current-username}}'; // Replace with actual username retrieval logic
  //   const id = this.recipe.id;
  //   this.recipeService.likeRecipe(id, username).subscribe(
  //     () => {
  //       this.loadLikesCount(id); // Refresh like count after liking
  //     },
  //     error => {
  //       console.error('Error liking recipe:', error);
  //     }
  //   );
  // }

  loadRecipes(): void {
    this.recipeService.getAllRecipes().subscribe(
      (data: Recipe[]) => {
        this.recipe = data.map(recipe => ({
          ...recipe,
          likesCount: this.recipeService.getLikesCount(recipe.id) // Call your service to fetch likes count
        }));
      },
      error => {
        console.error('Error fetching recipes', error);
      }
    );
  }

  // likeRecipe(): void {
  //   if (!this.recipe) return;

  //   const username = this.userService.getUsername();  // Assume you have a method to get the username
  //   this.recipeService.likeRecipe(this.recipe.id, username).subscribe(
  //     () => {
  //       console.log('Recipe liked successfully');
  //       this.loadRecipe(this.recipe.id);  // Refresh the recipe details to update likes count
  //     },
  //     error => {
  //       console.error('Error liking recipe', error);
  //     }
  //   );
  // }

  addLike(): void {
    this.likeCount++;
  }
  
}
