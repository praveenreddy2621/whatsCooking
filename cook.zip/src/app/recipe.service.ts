import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Recipe } from './recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  
  uploadImage(id: number, selectedImage: File) {
    throw new Error('Method not implemented.');
  }
  private baseURL = 'http://localhost:8087/recipes'; // Update with your backend URL

  constructor(private http: HttpClient) {}

  // Fetch all recipes
  getAllRecipes(): Observable<Recipe[]> {
    return this.http.get<Recipe[]>(`${this.baseURL}/all`); // Adjusted endpoint
  }

  createRecipe(recipe: Recipe): Observable<Recipe> {
    return this.http.post<Recipe>(`${this.baseURL}/post`, recipe); // Include recipe data in POST request
  }

  updateRecipe(id: number, recipe: Recipe): Observable<Recipe> {
    return this.http.put<Recipe>(`${this.baseURL}/${id}`, recipe);
  }

  deleteRecipe(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseURL}/${id}`);
  }

  // Fetch healthy recipes
  getHealthyRecipes(): Observable<Recipe[]> {
    return this.http.get<Recipe[]>(`${this.baseURL}/healthy`);
  }

  // Endorse a recipe
  endorseRecipe(recipeId: number, userId: number): Observable<any> {
    return this.http.post<any>(`${this.baseURL}/${recipeId}/endorse`, { userId });
  }
  getRecipeById(id: number): Observable<Recipe> {
    return this.http.get<Recipe>(`${this.baseURL}/${id}`);
  }
  img(id: number, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post(`${this.baseURL}/${id}/upload`, formData);
  }

  addLike(id: number): Observable<Recipe> {
    return this.http.post<Recipe>(`${this.baseURL}/${id}/like`, {});
  }

  // Add a comment to a recipe
  addComment(recipeId: number, content: string): Observable<Comment> {
    const comment = { recipeId, content };
    return this.http.post<Comment>('http://localhost:8087/comments/add', comment);
  }

  // //
  // likeRecipe(id: number): Observable<any> {
  //   return this.http.post<any>(`${this.baseURL}/${id}/like`, {});
  // }
  // //

  getRecipe(id: string): Observable<any> {
    return this.http.get<any>(`${this.baseURL}/${id}`);
  }

  // likeRecipe(recipeId: number, username: string): Observable<void> {
  //   return this.http.post<void>(`${this.baseURL}/${recipeId}/like`, null, { params: { username } });
  // }

  getLikesCount(recipeId: number): Observable<number> {
    return this.http.get<number>(`${this.baseURL}/${recipeId}/likes`);
  }

  //

  likeRecipe(recipeId: number, username: string): Observable<void> {
    return this.http.post<void>(`/recipes/${recipeId}/like?username=${username}`, {});
  }
  //
  
  
}
