package cooking.com.whatscooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;

@SpringBootApplication(scanBasePackages = "cooking.com.whatscooking")
@EnableAutoConfiguration(exclude= {ErrorMvcAutoConfiguration.class,org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration.class})
public class WhatscookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatscookingApplication.class, args);
		
		System.out.println("Started...!");
	}

}
