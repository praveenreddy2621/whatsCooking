package cooking.com.whatscooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import cooking.com.whatscooking.entity.Recipe;

public interface RecipeRepository extends JpaRepository<Recipe, Long> {
    List<Recipe> findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String nameKeyword, String descriptionKeyword);
    List<Recipe> findAllByOrderByNameAsc();
    List<Recipe> findAllByOrderByNameDesc();
    
    List<Recipe> findByNameContaining(String name);
    List<Recipe> findByNameContainingIgnoreCase(String name);
    List<Recipe> findByEndorsedTrue();
    List<Recipe> findByEndorsedFalse();
    
    //
  
    //

}
