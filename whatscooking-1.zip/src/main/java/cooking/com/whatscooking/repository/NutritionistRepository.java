//package cooking.com.whatscooking.repository;
//
//import cooking.com.whatscooking.entity.Nutritionist;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.Optional;
//
//public interface NutritionistRepository extends JpaRepository<Nutritionist, Long> {
//    Nutritionist findByUsername(String username);
//    Optional<Nutritionist> findById(Long id);
//}
