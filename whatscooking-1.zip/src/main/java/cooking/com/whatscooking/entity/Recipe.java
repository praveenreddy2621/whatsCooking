package cooking.com.whatscooking.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Transient;

@Entity
public class Recipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    @Column(length = 1000)
    private String description;
    @Column(length = 1000)
    private String ingredients;
    private String steps;
    private boolean enabled;
    private boolean endorsed;
    public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	private String img;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public String getSteps() {
		return steps;
	}
	public void setSteps(String steps) {
		this.steps = steps;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public boolean isEndorsed() {
		return endorsed;
	}
	public void setEndorsed(boolean endorsed) {
		this.endorsed = endorsed;
	}
	
	//
	 @ManyToMany
	    @JoinTable(
	        name = "recipe_likes",
	        joinColumns = @JoinColumn(name = "recipe_id"),
	        inverseJoinColumns = @JoinColumn(name = "user_id")
	    )
	    private Set<User> likedByUsers = new HashSet<>();

	    @Transient
	    private long likesCount;

	    // Getters and setters

	    public long getLikesCount() {
	        return likedByUsers.size();
	    }
		public Set<User> getLikedByUsers() {
			return likedByUsers;
		}
		public void setLikedByUsers(Set<User> likedByUsers) {
			this.likedByUsers = likedByUsers;
		}
		public void setLikesCount(long likesCount) {
			this.likesCount = likesCount;
		}
	 
	//

    
    
}
