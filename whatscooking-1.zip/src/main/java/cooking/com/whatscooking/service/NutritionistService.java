//package cooking.com.whatscooking.service;
//
//import cooking.com.whatscooking.entity.Nutritionist;
//import cooking.com.whatscooking.repository.NutritionistRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Optional;
//
//@Service
//public class NutritionistService {
//
//    @Autowired
//    private NutritionistRepository nutritionistRepository;
//
//    public Nutritionist addNutritionist(Nutritionist nutritionist) {
//        return nutritionistRepository.save(nutritionist);
//    }
//
//    public Nutritionist getNutritionistByUsername(String username) {
//        return nutritionistRepository.findByUsername(username);
//    }
//
//    public Nutritionist getNutritionistById(Long id) {
//        return nutritionistRepository.findById(id).orElse(null);
//    }
//
//    public Nutritionist updateNutritionist(Long id, Nutritionist nutritionist) {
//        if (nutritionistRepository.existsById(id)) {
//            nutritionist.setId(id);
//            return nutritionistRepository.save(nutritionist);
//        }
//        return null;
//    }
//
//    public void deleteNutritionist(Long id) {
//        nutritionistRepository.deleteById(id);
//    }
//}
