package cooking.com.whatscooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cooking.com.whatscooking.entity.Admin;
import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.exception.AdminNotFoundException;
import cooking.com.whatscooking.repository.AdminRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public Admin createAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public Admin getAdminByUsername(String username) {
        return adminRepository.findByUsername(username);
    }
    
//    public List<Admin> getAdmin() {
//        return adminRepository.findAll();
//    }

    public Admin updateAdmin(Long id, Admin adminDetails) {
        Admin admin = adminRepository.findById(id)
                .orElseThrow(() -> new AdminNotFoundException("Admin not found with ID: " + id));

        admin.setUsername(adminDetails.getUsername());
        admin.setPassword(adminDetails.getPassword());
        admin.setEmail(adminDetails.getEmail());
        admin.setRole(adminDetails.getRole());

        return adminRepository.save(admin);
    }

    public boolean deleteAdmin(Long id) {
        Admin admin = adminRepository.findById(id)
                .orElseThrow(() -> new AdminNotFoundException("Admin not found with ID: " + id));
        adminRepository.delete(admin);
        return true;
    }

	public List<Admin> getAdmin() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();	}
	
	  public Admin adminLogin(String email, String password) {
	        Admin admin = adminRepository.findByEmail(email);
	        if (admin != null) {
	            if (password.equals(admin.getPassword())) {  // Validate plain text password (not secure)
	                return admin;
	            }
	        }
	        return null;  // Return null if authentication fails
	    }
	 
}
