package cooking.com.whatscooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cooking.com.whatscooking.entity.Recipe;
import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.exception.RecipeNotFoundException;
import cooking.com.whatscooking.repository.RecipeRepository;
import cooking.com.whatscooking.repository.UserRepository;

@Service
public class RecipeService {
    @Autowired
    private RecipeRepository recipeRepository;
    
   

    @Autowired
    private UserRepository userRepository;

    public Recipe addRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    public Recipe getRecipeById(Long recipeId) {
        return recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));
    }

    public Recipe updateRecipe(Long recipeId, Recipe recipeDetails) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));

        recipe.setName(recipeDetails.getName());
        recipe.setDescription(recipeDetails.getDescription());
        recipe.setIngredients(recipeDetails.getIngredients());
        recipe.setSteps(recipeDetails.getSteps());
        recipe.setEnabled(recipeDetails.isEnabled());
        recipe.setEndorsed(recipeDetails.isEndorsed()); // Update endorsed field

        return recipeRepository.save(recipe);
    }

    public void deleteRecipe(Long recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));
        recipeRepository.delete(recipe);
    }

    public List<Recipe> searchRecipes(String keyword) {
        return recipeRepository.findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword, keyword);
    }

    public List<Recipe> filterAndSortRecipes(String filter, String sortOrder) {
        if ("name".equalsIgnoreCase(filter)) {
            return "asc".equalsIgnoreCase(sortOrder) ?
                    recipeRepository.findAllByOrderByNameAsc() :
                    recipeRepository.findAllByOrderByNameDesc();
        }
        // Add more filters as needed
        return recipeRepository.findAll();
    }

    public List<Recipe> getEndorsedRecipes() {
        return recipeRepository.findByEndorsedTrue();
    }

    public List<Recipe> getNonEndorsedRecipes() {
        return recipeRepository.findByEndorsedFalse();
    }
    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }
    
    //
    public void addLike(Long recipeId, String username) {
        Optional<Recipe> recipeOpt = recipeRepository.findById(recipeId);
        User user = userRepository.findByUsername(username);

        if (recipeOpt.isPresent() && user != null) {
            Recipe recipe = recipeOpt.get();
            if (!recipe.getLikedByUsers().contains(user)) {
                recipe.getLikedByUsers().add(user);
                recipeRepository.save(recipe);
            }
        }
    }
//    
//    public long getLikesCount(Long recipeId) {
//        return recipeRepository.findById(recipeId)
//                .map(Recipe::getLikesCount)
//                .orElse(0L);
//    }
    //
}
