package cooking.com.whatscooking.test;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
 
import java.util.Arrays;
 
import cooking.com.whatscooking.controller.AdminController;
import cooking.com.whatscooking.entity.Admin;
import cooking.com.whatscooking.service.AdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
 
public class AdminControllerTest {
 
    @Autowired
    private MockMvc mockMvc;
 
    @Mock
    private AdminService adminService;
 
    @InjectMocks
    private AdminController adminController;
 
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
    }
 
    @Test
    public void testCreateAdmin() throws Exception {
        Admin admin = new Admin();
        admin.setUsername("testuser");
        admin.setEmail("test@example.com");
        admin.setPassword("password");
 
        when(adminService.createAdmin(any(Admin.class))).thenReturn(admin);
 
        mockMvc.perform(post("/admins/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"testuser\",\"email\":\"test@example.com\",\"password\":\"password\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.username").value("testuser"));
    }
 
    @Test
    public void testGetAdmin() throws Exception {
        Admin admin = new Admin();
        admin.setUsername("testuser");
        admin.setEmail("test@example.com");
 
        when(adminService.getAdminByUsername("testuser")).thenReturn(admin);
 
        mockMvc.perform(get("/admins/testuser"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("testuser"));
    }
 
    @Test
    public void testGetAdminNotFound() throws Exception {
        when(adminService.getAdminByUsername("nonexistent")).thenReturn(null);
 
        mockMvc.perform(get("/admins/nonexistent"))
                .andExpect(status().isNotFound());
    }
 
    @Test
    public void testGetAllAdmins() throws Exception {
        Admin admin1 = new Admin();
        admin1.setUsername("admin1");
        admin1.setEmail("admin1@example.com");
 
        Admin admin2 = new Admin();
        admin2.setUsername("admin2");
        admin2.setEmail("admin2@example.com");
 
        when(adminService.getAdmin()).thenReturn(Arrays.asList(admin1, admin2));
 
        mockMvc.perform(get("/admins/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].username").value("admin1"))
                .andExpect(jsonPath("$[1].username").value("admin2"));
    }
 
    @Test
    public void testUpdateAdmin() throws Exception {
        Admin updatedAdmin = new Admin();
        updatedAdmin.setUsername("updateduser");
        updatedAdmin.setEmail("updated@example.com");
 
        when(adminService.updateAdmin(anyLong(), any(Admin.class))).thenReturn(updatedAdmin);
 
        mockMvc.perform(put("/admins/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"updateduser\",\"email\":\"updated@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("updateduser"));
    }
 
    @Test
    public void testDeleteAdmin() throws Exception {
        when(adminService.deleteAdmin(1L)).thenReturn(true);
 
        mockMvc.perform(delete("/admins/1"))
                .andExpect(status().isNoContent());
    }
 
    @Test
    public void testDeleteAdminNotFound() throws Exception {
        when(adminService.deleteAdmin(1L)).thenReturn(false);
 
        mockMvc.perform(delete("/admins/1"))
                .andExpect(status().isNotFound());
    }
 
    @Test
    public void testAdminLoginSuccess() throws Exception {
        Admin admin = new Admin();
        admin.setUsername("testuser");
        admin.setEmail("test@example.com");
 
        when(adminService.adminLogin("test@example.com", "password")).thenReturn(admin);
 
        mockMvc.perform(post("/admins/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"test@example.com\",\"password\":\"password\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("testuser"));
    }
 
    @Test
    public void testAdminLoginUnauthorized() throws Exception {
        when(adminService.adminLogin("test@example.com", "wrongpassword")).thenReturn(null);
 
        mockMvc.perform(post("/admins/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"test@example.com\",\"password\":\"wrongpassword\"}"))
                .andExpect(status().isUnauthorized());
    }
}
