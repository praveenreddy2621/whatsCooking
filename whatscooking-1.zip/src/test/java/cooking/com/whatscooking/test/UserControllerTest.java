package cooking.com.whatscooking.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
 
import java.util.List;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import cooking.com.whatscooking.controller.UserController;
import cooking.com.whatscooking.dto.LoginRequest;
import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.repository.UserRepository;
import cooking.com.whatscooking.service.UserService;
 
class UserControllerTest {
 
    @InjectMocks
    private UserController userController;
 
    @Mock
    private UserService userService;
 
    @Mock
    private UserRepository userRepository;
 
    private User testUser;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("test@example.com");
        testUser.setUsername("testUser");
        testUser.setPassword("password");
    }
 
    @Test
    void registerUser_shouldReturnCreatedUser() {
        when(userService.registerUser(any(User.class))).thenReturn(testUser);
 
        ResponseEntity<User> response = userController.registerUser(testUser);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(testUser, response.getBody());
    }
 
    @Test
    void loginUser_shouldReturnUser_whenCredentialsAreValid() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("test@example.com");
        loginRequest.setPassword("password");
        when(userService.loginUser(loginRequest.getEmailId(), loginRequest.getPassword())).thenReturn(testUser);
 
        ResponseEntity<?> response = userController.loginUser(loginRequest);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testUser, response.getBody());
    }
 
    @Test
    void getUser_shouldReturnUser_whenUserExists() {
        when(userService.getUserById(1L)).thenReturn(testUser);
 
        ResponseEntity<User> response = userController.getUser(1L);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testUser, response.getBody());
    }
 
    @Test
    void updateUser_shouldReturnUpdatedUser() {
        when(userService.updateUser(any(Long.class), any(User.class))).thenReturn(testUser);
 
        ResponseEntity<User> response = userController.updateUser(1L, testUser);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testUser, response.getBody());
    }
 
    @Test
    void deleteUser_shouldReturnNoContent() {
        when(userService.deleteUser(1L)).thenReturn(true);
 
        ResponseEntity<Void> response = userController.deleteUser(1L);
 
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
 
    @Test
    void getAllUsers_shouldReturnUserList() {
        when(userRepository.findAll()).thenReturn(List.of(testUser));
 
        List<User> response = userController.getAllUsers();
 
        assertEquals(1, response.size());
        assertEquals(testUser, response.get(0));
    }
}
