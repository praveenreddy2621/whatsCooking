package cooking.com.whatscooking.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import cooking.com.whatscooking.controller.RecipeController;
import cooking.com.whatscooking.entity.Recipe;
import cooking.com.whatscooking.service.RecipeService;
 
class RecipeControllerTest {
 
    @InjectMocks
    private RecipeController recipeController;
 
    @Mock
    private RecipeService recipeService;
 
    private Recipe testRecipe;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        testRecipe = new Recipe();
        testRecipe.setId(1L);
        testRecipe.setName("Test Recipe");
        testRecipe.setDescription("A delicious test recipe.");
    }
 
    @Test
    void addRecipe_shouldReturnAddedRecipe() {
        when(recipeService.addRecipe(any(Recipe.class))).thenReturn(testRecipe);
 
        Recipe response = recipeController.addRecipe(testRecipe);
 
        assertNotNull(response);
        assertEquals(testRecipe.getName(), response.getName());
    }
 
    @Test
    void getRecipe_shouldReturnRecipe_whenRecipeExists() {
        when(recipeService.getRecipeById(1L)).thenReturn(testRecipe);
 
        Recipe response = recipeController.getRecipe(1L);
 
        assertNotNull(response);
        assertEquals(testRecipe.getId(), response.getId());
    }
 
    @Test
    void updateRecipe_shouldReturnUpdatedRecipe() {
        when(recipeService.updateRecipe(any(Long.class), any(Recipe.class))).thenReturn(testRecipe);
 
        Recipe response = recipeController.updateRecipe(1L, testRecipe);
 
        assertNotNull(response);
        assertEquals(testRecipe.getName(), response.getName());
    }
 
    @Test
    void deleteRecipe_shouldInvokeServiceMethod() {
        doNothing().when(recipeService).deleteRecipe(1L);
 
        recipeController.deleteRecipe(1L);
 
        verify(recipeService, times(1)).deleteRecipe(1L);
    }
 
    @Test
    void searchRecipes_shouldReturnListOfRecipes() {
        List<Recipe> recipeList = new ArrayList<>();
        recipeList.add(testRecipe);
        
        when(recipeService.searchRecipes("Test")).thenReturn(recipeList);
 
        List<Recipe> response = recipeController.searchRecipes("Test");
 
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(testRecipe.getName(), response.get(0).getName());
    }
 
    @Test
    void filterAndSortRecipes_shouldReturnFilteredAndSortedList() {
        List<Recipe> recipeList = new ArrayList<>();
        recipeList.add(testRecipe);
        
        when(recipeService.filterAndSortRecipes("vegan", "asc")).thenReturn(recipeList);
 
        List<Recipe> response = recipeController.filterAndSortRecipes("vegan", "asc");
 
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(testRecipe.getName(), response.get(0).getName());
    }
 
    @Test
    void getAllRecipes_shouldReturnListOfAllRecipes() {
        List<Recipe> recipeList = new ArrayList<>();
        recipeList.add(testRecipe);
        
        when(recipeService.getAllRecipes()).thenReturn(recipeList);
 
        List<Recipe> response = recipeController.getAllRecipes();
 
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals(testRecipe.getName(), response.get(0).getName());
    }
}
