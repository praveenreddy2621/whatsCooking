package cooking.com.whatscooking.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
 
import cooking.com.whatscooking.controller.CommentController;
import cooking.com.whatscooking.entity.Comment;
import cooking.com.whatscooking.service.CommentService;
 
public class CommentControllerTest {
 
    @Autowired
    private MockMvc mockMvc;
 
    @Mock
    private CommentService commentService;
 
    @InjectMocks
    private CommentController commentController;
 
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(commentController).build();
    }
 
    @Test
    public void testAddComment() throws Exception {
        Comment comment = new Comment();
        comment.setId(1L);
        comment.setContent("This is a test comment");
 
        when(commentService.addComment(any(Comment.class))).thenReturn(comment);
 
        mockMvc.perform(post("/comments/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"content\":\"This is a test comment\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.content").value("This is a test comment"));
    }
 
    @Test
    public void testGetComment() throws Exception {
        Comment comment = new Comment();
        comment.setId(1L);
        comment.setContent("This is a test comment");
 
        when(commentService.getCommentById(1L)).thenReturn(comment);
 
        mockMvc.perform(get("/comments/{id}", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.content").value("This is a test comment"));
    }
 
	/*
	 * @Test public void testDeleteComment() throws Exception {
	 * doNothing().when(commentService).deleteComment(1L);
	 * 
	 * mockMvc.perform(delete("/comments/{id}", 1L))
	 * .andExpect(status().isNoContent());
	 * 
	 * verify(commentService, times(1)).deleteComment(1L); }
	 */
}